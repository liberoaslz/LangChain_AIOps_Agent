# Project Workflow

本文档按代码路径说明本项目从启动、接收用户问题、Agent 调度工具、RAG 混合检索、报告生成到评估验证的完整流程。

## 1. 总体流程图

```mermaid
flowchart TD
    A["用户输入运维问题"] --> B["Streamlit 前端接收输入"]
    B --> C["保存用户消息到 session_state"]
    C --> D["ReactAgent.execute_stream(prompt)"]
    D --> E["LangChain Agent.invoke"]
    E --> F["main_prompt 约束 Agent 行为"]
    F --> G{"Agent 根据问题选择工具"}

    G -->|运维知识问答| H["调用 rag_summarize"]
    G -->|服务异常分析| I["调用告警/指标/日志/拓扑工具"]
    G -->|运行报告生成| J["调用 fill_context_for_report"]

    H --> K["RagSummarizeService.rag_summarize"]
    K --> L["Query Rewrite"]
    L --> M["SemanticChecker 过滤无效改写"]
    M --> N["Chroma 向量检索 + BM25 关键词检索"]
    N --> O["RRF 融合"]
    O --> P["Reranker 精排"]
    P --> Q["拼接 RAG context"]
    Q --> R["RAG chain 生成知识库回答"]

    I --> S["工具返回结构化运维数据"]
    J --> T["middleware 设置 report=True"]
    T --> U["动态切换 report_prompt"]
    U --> V["fetch_report_data 聚合报告数据"]

    R --> W["Agent 汇总上下文"]
    S --> W
    V --> W
    W --> X["大模型生成最终回答"]
    X --> Y["ReactAgent 提取文本并分块输出"]
    Y --> Z["Streamlit 页面展示回答"]
```

## 2. 启动阶段

| 步骤 | 作用 | 对应代码 |
|---|---|---|
| 1 | Streamlit 设置页面标题、布局、侧边栏状态 | `app.py` |
| 2 | 页面注入 CSS，形成聊天界面风格 | `app.py` |
| 3 | 初始化 `ReactAgent`，并放入 `st.session_state["agent"]` | `app.py` |
| 4 | 初始化会话列表、当前会话 ID、快捷问题状态 | `app.py` |
| 5 | `ReactAgent.__init__` 创建 LangChain Agent | `agent/react_agent.py` |
| 6 | 注入聊天模型 `chat_model` | `agent/react_agent.py`、`model/factory.py` |
| 7 | 加载主系统提示词 `main_prompt.txt` | `agent/react_agent.py`、`utils/prompt_loader.py` |
| 8 | 注册 Agent 可调用工具 | `agent/react_agent.py`、`agent/tools/agent_tools.py` |
| 9 | 注册中间件：工具监控、模型调用前日志、报告提示词切换 | `agent/react_agent.py`、`agent/tools/middleware.py` |

启动完成后，项目形成一个包含模型、提示词、工具集合和中间件的 Agent 实例。

## 3. 前端接收用户问题

| 步骤 | 作用 | 对应代码 |
|---|---|---|
| 1 | 页面展示历史会话 | `app.py` |
| 2 | 用户通过输入框输入问题 | `app.py` |
| 3 | 用户也可以点击快捷问题生成待处理 prompt | `app.py` |
| 4 | 代码决定本轮使用快捷问题还是输入框内容 | `app.py` |
| 5 | 将用户消息加入当前会话 | `app.py` |
| 6 | 调用 `st.session_state["agent"].execute_stream(prompt)` | `app.py` |
| 7 | 前端逐块接收回答并显示 | `app.py` |

前端不负责判断问题类型，也不直接调用具体工具。前端只负责收集输入、调用 Agent、展示结果。

## 4. Agent 主流程

| 步骤 | 作用 | 对应代码 |
|---|---|---|
| 1 | `execute_stream` 接收用户问题 | `agent/react_agent.py` |
| 2 | 将用户问题包装成 LangChain messages 格式 | `agent/react_agent.py` |
| 3 | 调用 `self.agent.invoke(...)` 执行 Agent | `agent/react_agent.py` |
| 4 | 初始化运行上下文 `context={"report": False}` | `agent/react_agent.py` |
| 5 | Agent 根据提示词和工具描述决定是否调用工具 | `prompts/main_prompt.txt`、`agent/tools/agent_tools.py` |
| 6 | 工具调用结果进入 Agent 上下文 | `agent/tools/agent_tools.py` |
| 7 | Agent 汇总上下文并生成最终回答 | `agent/react_agent.py` |
| 8 | `_extract_text` 从返回 messages 中取最后一条模型内容 | `agent/react_agent.py` |
| 9 | 将完整回答切成小块，模拟流式输出给前端 | `agent/react_agent.py` |

这里的关键是 `create_agent`。它把模型、提示词、工具和中间件组合在一起，使模型可以根据用户问题自动选择工具。

## 5. 普通运维分析流程

普通运维分析问题示例：

```text
分析一下 order-service 最近1小时的异常情况
payment-service 今天有哪些高频异常
order-service 的问题可能会影响哪些下游服务
```

| 步骤 | 作用 | 对应代码 |
|---|---|---|
| 1 | 主提示词要求 Agent 理解用户的运维分析需求 | `prompts/main_prompt.txt` |
| 2 | 如果缺少服务名，Agent 可调用 `get_target_service` | `agent/tools/agent_tools.py` |
| 3 | 如果缺少时间范围，Agent 可调用 `get_time_range` | `agent/tools/agent_tools.py` |
| 4 | 调用 `fetch_alert_data` 查询告警数据 | `agent/tools/agent_tools.py` |
| 5 | 调用 `fetch_metric_data` 查询监控指标 | `agent/tools/agent_tools.py` |
| 6 | 调用 `fetch_log_summary` 查询日志摘要和高频错误 | `agent/tools/agent_tools.py` |
| 7 | 调用 `fetch_service_topology` 查询上下游依赖 | `agent/tools/agent_tools.py` |
| 8 | Agent 综合工具结果，输出问题分析、可能原因、排查步骤和解决建议 | `prompts/main_prompt.txt` |

普通运维分析使用的结构化数据位于：

| 数据类型 | 数据位置 |
|---|---|
| 服务列表 | `agent/tools/agent_tools.py` |
| 时间范围列表 | `agent/tools/agent_tools.py` |
| 告警数据 | `agent/tools/agent_tools.py` |
| 指标数据 | `agent/tools/agent_tools.py` |
| 日志数据 | `agent/tools/agent_tools.py` |
| 拓扑数据 | `agent/tools/agent_tools.py` |

这些数据用于验证 Agent 多工具协同流程。实际落地时，可以将工具内部的数据获取逻辑替换为 Prometheus、Elasticsearch、Loki、CMDB 或告警平台接口。

## 6. RAG 知识库问答流程

知识库问题示例：

```text
啥是 order_service
CPU 使用率过高一般怎么排查
服务不可用应该怎么处理
No space left on device 是什么问题
Too many connections 怎么排查
```

### 6.1 Agent 调用 RAG 工具

| 步骤 | 作用 | 对应代码 |
|---|---|---|
| 1 | Agent 判断问题需要运维知识库支持 | `prompts/main_prompt.txt` |
| 2 | 调用 `rag_summarize(query)` 工具 | `agent/tools/agent_tools.py` |
| 3 | `rag_summarize` 调用 `RagSummarizeService.rag_summarize` | `agent/tools/agent_tools.py`、`rag/rag_service.py` |
| 4 | RAG 服务检索相关文档并拼接 context | `rag/rag_service.py` |
| 5 | RAG chain 根据参考资料生成回答 | `rag/rag_service.py`、`prompts/rag_summarize.txt` |
| 6 | 结果返回给 Agent，进入最终回答上下文 | `agent/react_agent.py` |

### 6.2 RAG 检索总流程

```text
用户问题 query
↓
检查 query cache
↓
QueryRewriter 生成多个改写问题
↓
SemanticChecker 校验改写是否跑偏
↓
保留原问题 + 有效改写问题
↓
对每个 query 执行混合检索
↓
Chroma 向量检索
↓
BM25 关键词检索
↓
RRF 融合单个 query 的检索结果
↓
汇总多个 query 的候选文档
↓
再次 RRF 融合
↓
Reranker 使用原始 query 精排
↓
返回 Top 文档
↓
拼接 context
↓
LLM 基于参考资料生成回答
↓
写入 query cache
```

### 6.3 RAG 关键函数

| 函数/模块 | 作用 | 对应代码 |
|---|---|---|
| `RagSummarizeService.__init__` | 初始化向量库、提示词、模型和 RAG chain | `rag/rag_service.py` |
| `rag_summarize` | RAG 问答入口，负责缓存、检索、拼接上下文和模型总结 | `rag/rag_service.py` |
| `retriever_docs` | 对用户问题执行混合检索并返回文档 | `rag/rag_service.py` |
| `_hybrid_retrieval_single` | 对单个 query 执行 Chroma + BM25 + RRF | `rag/rag_service.py` |
| `_hybrid_retrieval_multi` | 对原问题和改写问题执行多路检索并融合 | `rag/rag_service.py` |
| `QueryRewriter.rewrite_multi_with_filter` | 生成多个检索改写问题并过滤 | `rag/query_rewriter.py` |
| `SemanticChecker.check_similarity` | 判断改写问题是否与原问题语义一致 | `rag/semantic_checker.py` |
| `BM25Retriever.retrieve` | 执行关键词检索 | `rag/bm25_retriever.py` |
| `rrf_fusion` | 按排名融合多路检索结果 | `rag/rrf_fusion.py` |
| `Reranker.rerank` | 对候选文档做最终精排 | `rag/reranker.py` |
| `query_cache` | 缓存重复查询结果 | `utils/cache.py` |

## 7. 知识库加载流程

向量库加载不是每次提问都执行，而是在初始化知识库或新增知识文档后执行。

| 步骤 | 作用 | 对应代码 |
|---|---|---|
| 1 | 创建 Chroma 向量库对象 | `rag/vector_store.py` |
| 2 | 创建 `RecursiveCharacterTextSplitter` 文本切分器 | `rag/vector_store.py` |
| 3 | 读取 `data/` 目录下允许类型的知识文件 | `rag/vector_store.py`、`utils/file_handler.py` |
| 4 | 计算文件 MD5，避免重复入库 | `rag/vector_store.py`、`utils/file_handler.py` |
| 5 | 根据文件类型调用 `TextLoader` 或 `PyPDFLoader` | `utils/file_handler.py` |
| 6 | 将原始文档切分成多个 chunk | `rag/vector_store.py` |
| 7 | 使用 Embedding 模型向量化文档片段 | `model/factory.py` |
| 8 | 写入 Chroma 向量库 | `rag/vector_store.py` |
| 9 | 保存已处理文件 MD5 | `rag/vector_store.py` |

相关配置来自 `config/chroma.yml`：

| 配置项 | 作用 |
|---|---|
| `collection_name` | Chroma collection 名称 |
| `persist_directory` | 向量库存储目录 |
| `k` | 检索返回文档片段数量 |
| `data_path` | 知识库文档目录 |
| `allow_knowledge_file_type` | 允许加载的文件类型 |
| `chunk_size` | 文本切分大小 |
| `chunk_overlap` | 文本切分重叠长度 |
| `md5_hex_store` | 已处理文件 MD5 记录文件 |

新增知识文档后，可执行：

```powershell
python -c "from rag.vector_store import VectorStoreService; v=VectorStoreService(); v.load_document(); print(v.vector_store._collection.count())"
```

## 8. BM25 关键词检索流程

BM25 用于处理运维场景中的精确关键词，例如：

```text
OOM
df -h
HTTP 500
Slow SQL
Too many connections
No space left on device
pod_restart_count
```

| 步骤 | 作用 | 对应代码 |
|---|---|---|
| 1 | 首次检索时懒加载 BM25 索引 | `rag/bm25_retriever.py` |
| 2 | 从 `data/` 目录读取 txt/pdf 文档 | `rag/bm25_retriever.py` |
| 3 | 使用 jieba 对中文文本分词 | `rag/bm25_retriever.py` |
| 4 | 基于分词结果构建 BM25 corpus | `rag/bm25_retriever.py` |
| 5 | 对用户 query 分词并计算 BM25 分数 | `rag/bm25_retriever.py` |
| 6 | 返回关键词相关性最高的 Document | `rag/bm25_retriever.py` |

BM25 解决的是关键词精确命中问题，Chroma 向量检索解决的是语义相似问题，两者在 RAG 中互补。

## 9. Query 改写与语义校验流程

用户运维问题经常比较口语化：

```text
CPU 飙高了
服务挂了咋办
接口慢得很
磁盘快爆了
```

系统通过 Query 改写将其转换为更适合检索的表达：

```text
CPU 使用率过高如何排查
服务不可用处理流程
接口响应时间过长定位方法
磁盘空间不足处理方案
```

| 步骤 | 作用 | 对应代码 |
|---|---|---|
| 1 | `QueryRewriter` 接收原始问题 | `rag/query_rewriter.py` |
| 2 | 调用模型生成多个改写问题 | `rag/query_rewriter.py` |
| 3 | 解析模型输出，得到改写 query 列表 | `rag/query_rewriter.py` |
| 4 | `SemanticChecker` 计算原问题和改写问题的 embedding 相似度 | `rag/semantic_checker.py` |
| 5 | 保留相似度达到阈值的改写问题 | `rag/query_rewriter.py`、`rag/semantic_checker.py` |
| 6 | 将原问题和有效改写问题一起送入混合检索 | `rag/rag_service.py` |

语义校验的作用是防止模型改写跑偏。例如原问题是 CPU 高，不能改写成数据库备份恢复。

## 10. RRF 融合与 Rerank 精排流程

### 10.1 单个 query 的融合

| 步骤 | 作用 | 对应代码 |
|---|---|---|
| 1 | 对同一个 query 执行 Chroma 向量检索 | `rag/rag_service.py`、`rag/vector_store.py` |
| 2 | 对同一个 query 执行 BM25 关键词检索 | `rag/rag_service.py`、`rag/bm25_retriever.py` |
| 3 | 使用 RRF 融合向量检索结果和 BM25 结果 | `rag/rrf_fusion.py` |
| 4 | 返回单个 query 的融合候选文档 | `rag/rag_service.py` |

### 10.2 多个 query 的融合

| 步骤 | 作用 | 对应代码 |
|---|---|---|
| 1 | 原问题和多个有效改写问题分别执行混合检索 | `rag/rag_service.py` |
| 2 | 汇总所有 query 的候选文档 | `rag/rag_service.py` |
| 3 | 再次使用 RRF 对候选文档进行融合 | `rag/rrf_fusion.py` |
| 4 | 得到全局候选文档列表 | `rag/rag_service.py` |

### 10.3 最终精排

| 步骤 | 作用 | 对应代码 |
|---|---|---|
| 1 | `Reranker` 接收原始 query 和融合候选文档 | `rag/reranker.py` |
| 2 | 分别计算 query 和候选文档的 embedding | `rag/reranker.py`、`model/factory.py` |
| 3 | 计算 query 与每个候选文档的余弦相似度 | `rag/reranker.py` |
| 4 | 按相似度重新排序，返回 Top 文档 | `rag/reranker.py` |

RRF 负责融合不同检索器和不同 query 的结果，Rerank 负责用原始用户问题对最终候选文档做精排。

## 11. 报告生成流程

报告问题示例：

```text
生成 inventory-service 本月运行报告
请给我一份 order-service 今日系统健康度分析
```

| 步骤 | 作用 | 对应代码 |
|---|---|---|
| 1 | 主提示词识别报告类请求 | `prompts/main_prompt.txt` |
| 2 | 如果缺少服务名，调用 `get_target_service` | `agent/tools/agent_tools.py` |
| 3 | 如果缺少时间范围，调用 `get_time_range` | `agent/tools/agent_tools.py` |
| 4 | 调用 `fill_context_for_report` 注入报告上下文 | `agent/tools/agent_tools.py` |
| 5 | `monitor_tool` 捕获工具调用过程 | `agent/tools/middleware.py` |
| 6 | 中间件检测到报告上下文后设置 `report=True` | `agent/tools/middleware.py` |
| 7 | `report_prompt_switch` 切换到 `report_prompt.txt` | `agent/tools/middleware.py` |
| 8 | 调用 `fetch_report_data` 聚合报告数据 | `agent/tools/agent_tools.py` |
| 9 | 如信息不足，补充调用告警、指标、日志、拓扑或 RAG 工具 | `agent/tools/agent_tools.py` |
| 10 | Agent 根据报告提示词输出结构化报告 | `prompts/report_prompt.txt` |

报告通常包含：

- 报告概览
- 核心指标表现
- 告警与异常情况
- 日志与根因分析
- 依赖与影响分析
- 综合判断
- 运维建议

## 12. 中间件流程

| 中间件 | 作用 | 对应代码 |
|---|---|---|
| `monitor_tool` | 记录工具名称、工具参数、调用成功或失败 | `agent/tools/middleware.py` |
| `monitor_tool` | 在报告上下文工具被调用后设置 `report=True` | `agent/tools/middleware.py` |
| `log_before_model` | 每次调用模型前记录当前消息数量和最后一条消息 | `agent/tools/middleware.py` |
| `report_prompt_switch` | 根据运行上下文选择主提示词或报告提示词 | `agent/tools/middleware.py` |

中间件让 Agent 的运行过程更可观察，也使报告模式可以通过上下文状态触发，而不需要在主流程中写死分支。

## 13. 模型与配置流程

| 步骤 | 作用 | 对应代码 |
|---|---|---|
| 1 | 从配置中读取聊天模型名称 | `config/rag.yml`、`model/factory.py` |
| 2 | 创建 `ChatTongyi` 作为 Agent 聊天模型 | `model/factory.py` |
| 3 | 从配置中读取 Embedding 模型名称 | `config/rag.yml`、`model/factory.py` |
| 4 | 创建 `DashScopeEmbeddings` 作为向量库 embedding 模型 | `model/factory.py` |
| 5 | 导出全局 `chat_model` 和 `embed_model` | `model/factory.py` |

配置文件主要包括：

| 配置文件 | 作用 |
|---|---|
| `config/rag.yml` | 模型名称配置 |
| `config/chroma.yml` | 向量库、知识库和文本切分配置 |
| `config/prompts.yml` | 提示词文件路径配置 |
| `config/agent.yml` | Agent 相关配置 |

## 14. 一次完整请求示例

以用户输入为例：

```text
啥是 order_service
```

实际链路如下：

| 顺序 | 发生的事情 | 对应代码 |
|---|---|---|
| 1 | 用户在页面输入问题 | `app.py` |
| 2 | 前端将用户消息写入会话 | `app.py` |
| 3 | 调用 `ReactAgent.execute_stream` | `agent/react_agent.py` |
| 4 | Agent 根据提示词和工具描述判断这是知识类问题 | `prompts/main_prompt.txt` |
| 5 | Agent 调用 `rag_summarize` 工具 | `agent/tools/agent_tools.py` |
| 6 | RAG 服务先检查缓存 | `utils/cache.py`、`rag/rag_service.py` |
| 7 | QueryRewriter 生成检索改写问题 | `rag/query_rewriter.py` |
| 8 | SemanticChecker 过滤无效改写 | `rag/semantic_checker.py` |
| 9 | 对原问题和有效改写问题执行 Chroma + BM25 检索 | `rag/rag_service.py` |
| 10 | RRF 融合检索结果 | `rag/rrf_fusion.py` |
| 11 | Reranker 对候选文档精排 | `rag/reranker.py` |
| 12 | 拼接 order_service 相关知识片段作为 context | `rag/rag_service.py` |
| 13 | RAG chain 生成基于参考资料的回答 | `prompts/rag_summarize.txt` |
| 14 | Agent 将结果作为最终回答返回 | `agent/react_agent.py` |
| 15 | 前端展示回答 | `app.py` |

再以用户输入为例：

```text
分析一下 order-service 最近1小时的异常情况
```

实际链路如下：

| 顺序 | 发生的事情 | 对应代码 |
|---|---|---|
| 1 | 用户在页面输入服务分析问题 | `app.py` |
| 2 | Agent 识别服务名为 `order-service`，时间范围为最近 1 小时 | `prompts/main_prompt.txt` |
| 3 | 调用告警工具获取告警情况 | `agent/tools/agent_tools.py` |
| 4 | 调用指标工具获取 CPU、内存、QPS、RT、错误率等指标 | `agent/tools/agent_tools.py` |
| 5 | 调用日志工具获取高频错误和日志摘要 | `agent/tools/agent_tools.py` |
| 6 | 调用拓扑工具获取上下游依赖 | `agent/tools/agent_tools.py` |
| 7 | Agent 汇总工具结果 | `agent/react_agent.py` |
| 8 | 模型输出问题分析、可能原因、排查步骤和解决建议 | `prompts/main_prompt.txt` |

## 15. RAG 评估流程

项目提供 RAG 评估脚本：

```powershell
python -m tests.rag_evaluation
```

### 15.1 测试用例结构

测试用例位于：

```text
tests/test_cases.json
```

每条测试用例通常包含：

| 字段 | 作用 |
|---|---|
| `id` | 测试用例编号 |
| `user_query` | 用户问题 |
| `expected_file` | 期望召回的知识文档 |
| `expected_keywords` | 期望回答中出现的关键词 |
| `note` | 用例说明 |

### 15.2 Recall@K 评估

`evaluate_recall_at_k` 用于评估检索器是否把正确文档召回到 Top K。

```text
Recall@K = Top K 中命中 expected_file 的问题数 / 总问题数
```

| 指标 | 含义 |
|---|---|
| `Recall@1` | 正确文档是否排在第 1 位 |
| `Recall@3` | 正确文档是否出现在前 3 个结果中 |
| `Recall@5` | 正确文档是否出现在前 5 个结果中 |

### 15.3 Keyword Hit Rate

`evaluate_answer_keywords` 用于评估最终生成答案是否包含预期关键词。

该指标不是严格语义正确率，而是回答质量的辅助指标，用于快速判断模型是否基于正确知识点作答。

## 16. 项目数据流总结

### 16.1 知识库问答数据流

```text
用户问题
-> Agent
-> rag_summarize 工具
-> Query Rewrite
-> Semantic Check
-> Chroma + BM25
-> RRF Fusion
-> Rerank
-> RAG Context
-> LLM
-> 前端展示
```

### 16.2 服务异常分析数据流

```text
用户问题
-> Agent
-> 告警工具
-> 指标工具
-> 日志工具
-> 拓扑工具
-> 上下文聚合
-> LLM
-> 前端展示
```

### 16.3 报告生成数据流

```text
用户问题
-> Agent
-> fill_context_for_report
-> middleware 设置 report=True
-> report_prompt_switch
-> fetch_report_data
-> 报告上下文聚合
-> LLM
-> 前端展示
```

## 17. 当前项目边界

当前项目重点验证：

- Agent 多工具协同流程
- 运维知识库问答
- RAG 混合检索链路
- 服务异常分析链路
- 结构化报告生成链路
- RAG 召回与回答质量评估

当前工具层使用结构化模拟数据，便于完整演示 Agent 工作流。后续接入真实系统时，只需要替换工具内部数据获取逻辑，Agent 主流程和 RAG 主流程可以保持不变。
