
"""
总结服务类：用户提问，搜索参考资料，将提问和参考资料提交给模型，让模型总结回复
"""
from langchain_core.documents import Document
from langchain_core.output_parsers import StrOutputParser

from concurrent.futures import ThreadPoolExecutor, as_completed
from rag.vector_store import VectorStoreService
from rag.query_rewriter import QueryRewriter
from rag.bm25_retriever import BM25Retriever
from rag.reranker import Reranker
from rag.rrf_fusion import rrf_fusion
from utils.prompt_loader import load_rag_prompts
from langchain_core.prompts import PromptTemplate
from model.factory import chat_model
from utils.cache import query_cache


def print_prompt(prompt):
    print("="*20)
    print(prompt.to_string())
    print("="*20)
    return prompt


class RagSummarizeService(object):
    def __init__(self):
        self.vector_store = VectorStoreService()
        self.retriever = self.vector_store.get_retriever()
        self._vector_retriever = None
        self._query_rewriter = None
        self._bm25_retriever = None
        self._reranker = None
        self.prompt_text = load_rag_prompts()
        self.prompt_template = PromptTemplate.from_template(self.prompt_text)
        self.model = chat_model
        self.chain = self._init_chain()

    def _init_chain(self):
        chain = self.prompt_template | print_prompt | self.model | StrOutputParser()
        return chain

    def _get_vector_retriever(self):
        if self._vector_retriever is None:
            self._vector_retriever = self.retriever
        return self._vector_retriever

    def _get_query_rewriter(self):
        if self._query_rewriter is None:
            self._query_rewriter = QueryRewriter()
        return self._query_rewriter

    def _get_bm25_retriever(self):
        if self._bm25_retriever is None:
            self._bm25_retriever = BM25Retriever()
        return self._bm25_retriever

    def _get_reranker(self):
        if self._reranker is None:
            self._reranker = Reranker()
        return self._reranker

    def _hybrid_retrieval_single(self, query: str) -> list[Document]:
        """单个Query的混合召回作用：对一个 query 同时做两种检索。
        Chroma 向量检索
        BM25 关键词检索
        RRF 融合"""
        with ThreadPoolExecutor(max_workers=2) as executor:
            vector_future = executor.submit(self._get_vector_retriever().invoke, query)
            bm25_future = executor.submit(self._get_bm25_retriever().retrieve, query)
            vector_docs = vector_future.result()
            bm25_docs = bm25_future.result()
        return rrf_fusion(vector_docs, bm25_docs)

    def _hybrid_retrieval_multi(self, queries: list) -> list[Document]:
        """多路Query召回：并行执行，每个Query各自召回，然后融合所有结果
        作用：对原问题 + 改写问题并行检索。
        query 原文
        改写1
        改写2
        改写3
        分别做 hybrid retrieval
        最后再 RRF 融合一次"""
        all_docs = []

        # 并行执行所有Query的混合召回
        with ThreadPoolExecutor(max_workers=len(queries)) as executor:
            futures = {executor.submit(self._hybrid_retrieval_single, q["text"]): q for q in queries}
            for future in as_completed(futures):
                docs = future.result()
                all_docs.extend(docs)

        if not all_docs:
            return []

        return rrf_fusion(all_docs, [], k=60, top_n=20)

    def retriever_docs(self, query: str) -> list[Document]:
        """完整的检索流程：多路改写 → 多路召回 → Rerank精排"""
        # 1. 多路改写并过滤（相似度≥0.8）
        valid_rewrites = self._get_query_rewriter().rewrite_multi_with_filter(
            query,
            num_rewrites=3,
            threshold=0.8
        )

        # 2. 准备所有要召回的Query（包括原Query）
        queries_to_retrieve = [{"text": query, "similarity": 1.0}]
        queries_to_retrieve.extend(valid_rewrites)

        # 3. 多路召回
        fused_docs = self._hybrid_retrieval_multi(queries_to_retrieve)

        # 4. Rerank精排（使用原Query进行精排）
        reranked_docs = self._get_reranker().rerank(query, fused_docs)

        return reranked_docs

    def rag_summarize(self, query: str) -> str:

        cached = query_cache.get(query, service="rag")
        if cached:
            return cached

        context_docs = self.retriever_docs(query)

        context = ""
        counter = 0
        for doc in context_docs:
            counter += 1
            context += f"【参考资料{counter}】: 参考资料：{doc.page_content} | 参考元数据：{doc.metadata}\n"

        result = self.chain.invoke(
            {
                "input": query,
                "context": context,
            }
        )
        query_cache.set(query, result, service="rag")
        return result


if __name__ == '__main__':
    rag = RagSummarizeService()
