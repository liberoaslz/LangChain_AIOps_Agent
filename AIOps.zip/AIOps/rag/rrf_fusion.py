from langchain_core.documents import Document
from typing import List

def rrf_fusion(
    vector_results: List[Document],
    bm25_results: List[Document],
    k: int = 60,
    top_n: int = 10
) -> List[Document]:
    """把向量检索结果和 BM25 检索结果合并排序,它不是看原始分数，而是看排名。
        某文档在向量检索排第 1
        得分 += 1 / (60 + 1)
        某文档在 BM25 排第 3
        得分 += 1 / (60 + 3)
        如果一个文档同时被向量检索和 BM25 命中，它的总分会更高。
    """
    doc_scores = {}

    for rank, doc in enumerate(vector_results, 1):
        doc_id = hash(doc.page_content)
        if doc_id not in doc_scores:
            doc_scores[doc_id] = {"doc": doc, "score": 0}
        doc_scores[doc_id]["score"] += 1 / (k + rank)

    for rank, doc in enumerate(bm25_results, 1):
        doc_id = hash(doc.page_content)
        if doc_id not in doc_scores:
            doc_scores[doc_id] = {"doc": doc, "score": 0}
        doc_scores[doc_id]["score"] += 1 / (k + rank)

    sorted_docs = sorted(doc_scores.values(), key=lambda x: x["score"], reverse=True)
    return [item["doc"] for item in sorted_docs[:top_n]]