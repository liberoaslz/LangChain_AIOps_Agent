import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from rag.rag_service import RagSummarizeService


def load_test_cases():
    test_file = os.path.join(os.path.dirname(__file__), "test_cases.json")
    with open(test_file, "r", encoding="utf-8") as f:
        return json.load(f)


def get_source(doc):
    source = doc.metadata.get("source", "")
    return source.replace("\\", "/")


def evaluate_recall():
    rag = RagSummarizeService()
    cases = load_test_cases()

    hit_1 = 0
    hit_3 = 0
    hit_5 = 0
    total = len(cases)
    details = []

    for case in cases:
        query = case.get("user_query") or case.get("query")
        expected_file = case["expected_file"]

        docs = rag.retriever_docs(query)[:5]
        sources = [get_source(doc) for doc in docs]

        hit_at_1 = any(expected_file in source for source in sources[:1])
        hit_at_3 = any(expected_file in source for source in sources[:3])
        hit_at_5 = any(expected_file in source for source in sources[:5])

        if hit_at_1:
            hit_1 += 1
        if hit_at_3:
            hit_3 += 1
        if hit_at_5:
            hit_5 += 1

        details.append({
            "id": case["id"],
            "query": query,
            "expected_file": expected_file,
            "sources": sources,
            "hit_at_1": hit_at_1,
            "hit_at_3": hit_at_3,
            "hit_at_5": hit_at_5,
        })

        print("=" * 60)
        print("ID:", case["id"])
        print("问题:", query)
        print("期望文档:", expected_file)
        print("Top5 召回文档:")

        for i, source in enumerate(sources, 1):
            mark = "✓" if expected_file in source else " "
            print(f"{i}. [{mark}] {source}")

        print("Hit@1:", hit_at_1)
        print("Hit@3:", hit_at_3)
        print("Hit@5:", hit_at_5)

    recall_1 = hit_1 / total if total else 0
    recall_3 = hit_3 / total if total else 0
    recall_5 = hit_5 / total if total else 0

    print("\n" + "=" * 60)
    print(f"Recall@1: {hit_1}/{total} = {recall_1:.2%}")
    print(f"Recall@3: {hit_3}/{total} = {recall_3:.2%}")
    print(f"Recall@5: {hit_5}/{total} = {recall_5:.2%}")

    return {
        "recall_at_1": recall_1,
        "recall_at_3": recall_3,
        "recall_at_5": recall_5,
        "hit_1": hit_1,
        "hit_3": hit_3,
        "hit_5": hit_5,
        "total": total,
        "details": details,
    }


def evaluate_answer_keywords(limit=5):
    rag = RagSummarizeService()
    cases = load_test_cases()[:limit]

    hit = 0
    total = len(cases)

    for case in cases:
        query = case.get("user_query") or case.get("query")
        answer = rag.rag_summarize(query)
        keywords = case.get("expected_keywords", [])

        matched = [kw for kw in keywords if kw in answer]
        ok = len(matched) >= min(2, len(keywords))

        if ok:
            hit += 1

        print("=" * 60)
        print("ID:", case["id"])
        print("问题:", query)
        print("期望关键词:", keywords)
        print("命中关键词:", matched)
        print("是否通过:", ok)
        print("回答预览:", answer[:300])

    rate = hit / total if total else 0
    print("\n" + "=" * 60)
    print(f"Keyword Hit Rate: {hit}/{total} = {rate:.2%}")

    return {
        "keyword_hit_rate": rate,
        "hit": hit,
        "total": total,
    }


if __name__ == "__main__":
    evaluate_recall()
    print("\n\n开始测试回答关键词命中率（默认前5条，避免调用模型太多）")
    evaluate_answer_keywords(limit=5)